rootProject.name = "java-oxford-dictionaries"
